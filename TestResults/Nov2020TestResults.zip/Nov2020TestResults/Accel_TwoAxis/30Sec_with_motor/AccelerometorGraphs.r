library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)

file <- read.csv("C:/Users/Walte/Desktop/Nov2020TestResults/Accel_TwoAxis/30Sec_with_motor/accel.csv", header = TRUE, sep=",")

head(file)

#remove NA columns
df <- file[,colSums(is.na(file))<nrow(file)]

startTime = as.numeric(df$TRANSACTION_TIME_TICKS[1])

#replace ticks with seconds
df <- df %>% mutate (TRANSACTION_TIME_TICKS = as.numeric(TRANSACTION_TIME_TICKS) - startTime)
head(df)

#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")


accel_x <- df %>% ggplot(aes(y = ACCEL_X,x = ID )) + geom_line() + ggtitle("Accel X")
accel_y <- df %>% ggplot(aes(y = ACCEL_Y,x = ID )) + geom_line() + ggtitle("Accel Y")
accel_z <- df %>% ggplot(aes(y = ACCEL_Z,x = ID )) + geom_line() + ggtitle("Accel Z")

temp <- df %>% ggplot(aes(y = CPU_TEMP,x = ID )) + geom_line() + ggtitle("Temp (F)")



grid.arrange(accel_x, accel_y, accel_z, temp, ncol= 1)


#data is approximately 8700 sps long
split <- split(df, (as.numeric(rownames(df))-1) %/% 8700)


plot_data_column = function (data) {
  titlex <- paste("Accel X", max(data$ID) / 8700)
  ggplot(data, aes(y = data$ACCEL_X,x = data$ID )) + geom_line() + ggtitle(titlex) + xlab("ID") +ylab("Voltage")
}

myplots <- lapply(split, plot_data_column)

save <- function(p) { p }

#save a quick pdf of the list of graphs
pdf("C:/Users/Walte/Desktop/Nov2020TestResults/Accel_TwoAxis/30Sec_with_motor/Accel_X_Graphs.pdf", onefile = TRUE)
for (i in seq(length(myplots))) {
  grid.arrange(myplots[[i]])
}
dev.off()

#save larger versions of the graphs
for (i in seq(length(myplots))) {
  file_ <- paste("C:/Users/Walte/Desktop/Nov2020TestResults/Accel_TwoAxis/30Sec_with_motor/Graphs/", i, ".png")
  ggsave(file=file_, myplots[[i]], device= "png", width= 23.16, height= 13.60)
}
