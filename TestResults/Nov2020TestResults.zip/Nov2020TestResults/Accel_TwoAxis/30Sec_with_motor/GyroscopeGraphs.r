library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)

file <- read.csv("C:/Users/Walte/Desktop/Nov2020TestResults/Accel_TwoAxis/30Sec_with_motor/gyro.csv", header = TRUE, sep=",")

head(file)

#remove NA columns
df <- file[,colSums(is.na(file))<nrow(file)]

#replace ticks with dates
df <- df %>% mutate (TRANSACTION_TIME_TICKS = format(as.POSIXct((TRANSACTION_TIME_TICKS / 1e7), origin='0001-01-01', tx='GMT'), "%H:%M:%OS6"))
head(df)

#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")


gyro_x <- df %>% ggplot(aes(y = GYRO_X,x = ID )) + geom_line()
gyro_y <- df %>% ggplot(aes(y = GYRO_Y,x = ID )) + geom_line()
gyro_z <- df %>% ggplot(aes(y = GYRO_Z,x = ID )) + geom_line()

accel_x <- df %>% ggplot(aes(y = ACCEL_X.1,x = ID )) + geom_line()
accel_y <- df %>% ggplot(aes(y = ACCEL_Y.1,x = ID )) + geom_line()
accel_z <- df %>% ggplot(aes(y = ACCEL_Z.1,x = ID )) + geom_line()

temp <- df %>% ggplot(aes(y = CPU_TEMP,x = ID )) + geom_line()



grid.arrange(gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z, temp, ncol= 1)

