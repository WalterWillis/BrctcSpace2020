library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)
library(spectral)

#Indexes may be off by 1 in some cases

#-------------------------------------------------------------------------------------

#My code's output
file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 2/FrequencyDomain.csv", header = TRUE, sep=",")

head(file)
df <- file[,colSums(is.na(file))<nrow(file)]
#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")

titlex <- "Phase At Frequency"
#df %>% filter(Frequency < 31, Frequency >= 26) %>%
#ggplot(aes(y = Phase,x = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Phase")

#df %>% filter(Frequency < 31, Frequency >= 26) %>%
#  ggplot(aes(x = Magnitude,y = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Magnitude") +ylab("Frequency")


titlex <- "My Algorithm: Magnitude At Frequency"
P_1 <- df %>% filter(ID < 4000, ID >= 2) %>%
  ggplot(aes(x = ID,y = Magnitude )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")

titlex <- "My Algorithm: Zoomed"
P_3 <- df %>% filter(ID < 85, ID >= 2) %>%
  ggplot(aes(x = ID,y = Magnitude )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")

vals <- tail(order(df$Magnitude), 21)

trun <- df %>% filter(ID %in% vals, ID >1)

titlex <- "My Algorithm: Summary of Maximums - Zoomed"
P_5 <- trun %>% filter(ID < 85, ID >= 2) %>%
  ggplot(aes(x = ID,y = Magnitude )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")


titlex <- "My Algorithm: Summary of Maximums - Remainder"
P_6 <- trun %>% filter(ID < 4000, ID > 30) %>%
  ggplot(aes(x = ID,y = Magnitude )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")


#-------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------

#R version of fft found online (forget where)
file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 2/accel_withSeconds.csv", header = TRUE, sep=",")

#remove NA columns
df <- file[,colSums(is.na(file))<nrow(file)]

#remove last time portion since it's likely not a full second
#df <- df %>% filter(TRANSACTION_TIME_TICKS != 61)

#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")

data <- df %>% filter(TRANSACTION_TIME_TICKS == 4) %>% pull(ACCEL_Y)

result = fft(data)

tail(order(result), 20)

titlex <- "R Algorithm: Magnitude At Frequency"
 d <- data.frame(X = c(2:4000), Y = abs(result)[2:4000] )
 P_2 <- d %>% ggplot(aes(x = X,y = Y )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")
 
 titlex <- "R Algorithm: Zoomed"
 d <- data.frame(X = c(2:85), Y = abs(result)[2:85] )
 P_4 <- d %>% ggplot(aes(x = X,y = Y )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")
#plot(abs(result)[2:4000], type="h")
 

#-------------------------------------------------------------------------------------



grid.arrange(P_1, P_2, P_3, P_4, P_5, P_6, ncol= 1)
