library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)

file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 2/FrequencyDomain.csv", header = TRUE, sep=",")

head(file)
df <- file[,colSums(is.na(file))<nrow(file)]
#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")

titlex <- "Phase At Frequency"
df %>% filter(Frequency < 31, Frequency >= 26) %>%
ggplot(aes(y = Phase,x = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Phase")

df %>% filter(Frequency < 31, Frequency >= 26) %>%
  ggplot(aes(x = Magnitude,y = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Magnitude") +ylab("Frequency")
