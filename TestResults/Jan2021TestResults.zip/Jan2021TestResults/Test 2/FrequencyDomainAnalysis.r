library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)
library(spectral)

#-------------------------------------------------------------------------------------

#My code's output
file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 2/FrequencyDomain.csv", header = TRUE, sep=",")

head(file)
df <- file[,colSums(is.na(file))<nrow(file)]
#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")

titlex <- "Phase At Frequency"
#df %>% filter(Frequency < 31, Frequency >= 26) %>%
#ggplot(aes(y = Phase,x = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Phase")

#df %>% filter(Frequency < 31, Frequency >= 26) %>%
#  ggplot(aes(x = Magnitude,y = Frequency )) + geom_line() + ggtitle(titlex) + xlab("Magnitude") +ylab("Frequency")

titlex <- "My Algorithm: Magnitude At Frequency"
P_1 <- df %>% filter(ID < 4000, ID >= 2) %>%
  ggplot(aes(x = ID,y = Magnitude )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")

#-------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------

#R version of fft found online (forget where)
file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 2/accel_withSeconds.csv", header = TRUE, sep=",")

#remove NA columns
df <- file[,colSums(is.na(file))<nrow(file)]

#remove last time portion since it's likely not a full second
#df <- df %>% filter(TRANSACTION_TIME_TICKS != 61)

#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")

data <- df %>% filter(TRANSACTION_TIME_TICKS == 4) %>% pull(ACCEL_Y)

result = fft(data)

titlex <- "R Algorithm: Magnitude At Frequency"
 d <- data.frame(X = c(2:4000), Y = abs(result)[2:4000] )
 P_2 <- d %>% ggplot(aes(x = X,y = Y )) + geom_line() + ggtitle(titlex) + xlab("Frequency") +ylab("Magnitude")
#plot(abs(result)[2:4000], type="h")

#-------------------------------------------------------------------------------------



grid.arrange(P_1, P_2, ncol= 1)
