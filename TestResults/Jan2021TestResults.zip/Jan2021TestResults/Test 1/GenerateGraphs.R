library(dslabs)
library(tidyverse)
library(gridExtra)
library(GeneCycle)

file <- read.csv("C:/Users/Walte/Desktop/Jan2021TestResults/Test 1/accel_withSeconds.csv", header = TRUE, sep=",")

head(file)


#remove NA columns
df <- file[,colSums(is.na(file))<nrow(file)]
tail(df)
#remove last time portion since it's likely not a full second
#df <- df %>% filter(TRANSACTION_TIME_TICKS != 61)
head(df)
tail(df)

#add row id since transaction time isn't specific enough (points line up)
df <- tibble::rowid_to_column(df, "ID")



accel_x <- df %>% ggplot(aes(y = ACCEL_X,x = ID )) + geom_line() + ggtitle("Accel X")
accel_y <- df %>% ggplot(aes(y = ACCEL_Y,x = ID )) + geom_line() + ggtitle("Accel Y")
accel_z <- df %>% ggplot(aes(y = ACCEL_Z,x = ID )) + geom_line() + ggtitle("Accel Z")

temp <- df %>% ggplot(aes(y = CPU_TEMP,x = ID )) + geom_line() + ggtitle("Temp (F)")



grid.arrange(accel_x, accel_y, accel_z, temp, ncol= 1)


#data is approximately 8700 sps long
split <- split(df, df$TRANSACTION_TIME_TICKS)


plot_data_column = function (data) {
  titlex <- paste("Accel X",length(data$TRANSACTION_TIME_TICKS))
  ggplot(data, aes(y = data$ACCEL_X,x = data$ID )) + geom_line() + ggtitle(titlex) + xlab("ID") +ylab("Voltage")
}

myplots <- lapply(split, plot_data_column)

save <- function(p) { p }

#save a quick pdf of the list of graphs
pdf("C:/Users/Walte/Desktop/Jan2021TestResults/Test 1/Accel_X_Graphs.pdf", onefile = TRUE)
for (i in seq(length(myplots))) {
  grid.arrange(myplots[[i]])
}
dev.off()

#save larger versions of the graphs
for (i in seq(length(myplots))) {
  file_ <- paste("C:/Users/Walte/Desktop/Jan2021TestResults/Test 1/Graphs/", i, ".png")
  ggsave(file=file_, myplots[[i]], device= "png", width= 23.16, height= 13.60)
}
